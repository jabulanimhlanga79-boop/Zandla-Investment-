package com.zandla.investment

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF063A70)
private val Blue = Color(0xFF0B5EAE)
private val Gold = Color(0xFFF5B51B)
private val Light = Color(0xFFF4F7FB)

data class Transaction(val service: String, val reference: String, val amount: String, val status: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZandlaApp() }
    }
}

@Composable
fun ZandlaApp() {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy,
            secondary = Gold,
            background = Light
        )
    ) {
        var tab by remember { mutableStateOf(0) }
        var screen by remember { mutableStateOf("home") }

        Scaffold(
            bottomBar = {
                NavigationBar {
                    listOf("Home", "History", "Account", "More").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i; screen = if (i == 0) "home" else label.lowercase() },
                            icon = { Text(listOf("⌂", "◷", "●", "☰")[i], fontSize = 20.sp) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (screen) {
                    "home" -> HomeScreen(
                        onService = { screen = it },
                        onWhatsApp = { openWhatsApp() }
                    )
                    "flash" -> ServiceScreen(
                        title = "Flash Token",
                        icon = "⚡",
                        fields = listOf("Flash Account Number", "Token Amount"),
                        amounts = listOf("R50", "R100", "R200", "R300", "R500", "R1,000"),
                        charge = "R7.00",
                        onBack = { screen = "home" }
                    )
                    "dstv" -> ServiceScreen(
                        title = "DStv",
                        icon = "📺",
                        fields = listOf("DStv Account Number", "Package"),
                        amounts = listOf("Access", "Family", "Compact", "Compact Plus", "Premium"),
                        charge = "R13.00",
                        onBack = { screen = "home" }
                    )
                    "airtime" -> ServiceScreen(
                        title = "Airtime & Data",
                        icon = "📱",
                        fields = listOf("Phone Number", "Network", "Amount"),
                        amounts = listOf("E10", "E20", "E30", "E50", "E100"),
                        charge = "E1.00",
                        onBack = { screen = "home" }
                    )
                    "history" -> HistoryScreen()
                    "account" -> AccountScreen(onWhatsApp = { openWhatsApp() })
                    "more" -> MoreScreen()
                }
            }
        }
    }
}

@Composable
fun Header(title: String, onBack: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().background(Navy).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            Text("‹", color = Color.White, fontSize = 34.sp,
                modifier = Modifier.clickable { onBack() }.padding(end = 12.dp))
        }
        Column {
            Text("ZANDLA", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("INVESTMENT", color = Color.White, fontSize = 11.sp, letterSpacing = 2.sp)
        }
        Spacer(Modifier.weight(1f))
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun HomeScreen(onService: (String) -> Unit, onWhatsApp: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().background(Light),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Header("Home")
            Column(Modifier.padding(18.dp)) {
                Text("Hello, Jabulani", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("Welcome to Zandla Investment", color = Color.Gray)
                Spacer(Modifier.height(18.dp))
                Text("Fast • Safe • Reliable", color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Your digital services in one place", color = Color.Gray)
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ServiceCard("⚡", "Flash Token", "Buy Flash Tokens") { onService("flash") }
                    ServiceCard("📺", "DStv", "Pay DStv") { onService("dstv") }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ServiceCard("📱", "Airtime & Data", "Top Up & Bundles") { onService("airtime") }
                    ServiceCard("💳", "Payments", "More Services") { onService("more") }
                }
                Spacer(Modifier.height(22.dp))
                Button(
                    onClick = onWhatsApp,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF18B956))
                ) { Text("Chat on WhatsApp  •  76610622", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
fun ServiceCard(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.weight(1f).height(150.dp).clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 34.sp)
            Text(title, fontWeight = FontWeight.Bold, color = Navy, fontSize = 16.sp)
            Text(subtitle, color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
fun ServiceScreen(
    title: String, icon: String, fields: List<String>, amounts: List<String>,
    charge: String, onBack: () -> Unit
) {
    var selected by remember { mutableStateOf(amounts.first()) }
    var submitted by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(Light)) {
        Header(title, onBack)
        LazyColumn(contentPadding = PaddingValues(18.dp)) {
            item {
                Text("$icon  $title", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
                Spacer(Modifier.height(16.dp))
                fields.forEach { field ->
                    OutlinedTextField(
                        value = if (field == "Amount") selected else "",
                        onValueChange = {},
                        label = { Text(field) },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        readOnly = field == "Amount"
                    )
                }
                Text("Select Amount / Package", fontWeight = FontWeight.SemiBold, color = Navy)
                Spacer(Modifier.height(8.dp))
                amounts.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { amount ->
                            OutlinedButton(
                                onClick = { selected = amount },
                                modifier = Modifier.weight(1f),
                                colors = if (selected == amount)
                                    ButtonDefaults.outlinedButtonColors(containerColor = Gold)
                                else ButtonDefaults.outlinedButtonColors()
                            ) { Text(amount) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Card(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Service charge: $charge")
                        Text("Total will be confirmed before payment.", color = Color.Gray, fontSize = 12.sp)
                    }
                }
                Button(
                    onClick = { submitted = true },
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) { Text("Proceed to Payment", fontWeight = FontWeight.Bold) }

                if (submitted) {
                    Spacer(Modifier.height(14.dp))
                    Text(
                        "Request created. In Version 1.0, payment is confirmed manually by Zandla Investment.",
                        color = Navy,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
fun HistoryScreen() {
    val data = listOf(
        Transaction("DStv Payment", "102807997", "R312.00", "Success"),
        Transaction("Flash Token", "1234567890", "R57.00", "Success"),
        Transaction("Airtime Purchase", "76123456 (MTN)", "E11.00", "Success")
    )
    Column(Modifier.fillMaxSize().background(Light)) {
        Header("Transaction History")
        LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(data) { t ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(t.service, fontWeight = FontWeight.Bold, color = Navy)
                            Text(t.reference, color = Color.Gray, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(t.amount, fontWeight = FontWeight.Bold)
                            Text(t.status, color = Color(0xFF168A42), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AccountScreen(onWhatsApp: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Light)) {
        Header("Account")
        Column(Modifier.padding(18.dp)) {
            Text("Jabulani Mhlanga", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text("Customer account", color = Color.Gray)
            Spacer(Modifier.height(18.dp))
            listOf("My Profile", "Saved Accounts", "Transaction History", "Receipts", "Help & Support", "About Zandla Investment").forEach {
                Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Row(Modifier.padding(17.dp)) {
                        Text(it, fontWeight = FontWeight.SemiBold, color = Navy)
                        Spacer(Modifier.weight(1f))
                        Text("›", fontSize = 22.sp)
                    }
                }
            }
            Button(onClick = onWhatsApp, modifier = Modifier.fillMaxWidth()) {
                Text("Contact us on WhatsApp")
            }
        }
    }
}

@Composable
fun MoreScreen() {
    Column(Modifier.fillMaxSize().background(Light)) {
        Header("More Services")
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("💳  Payment Methods", "📺  TV Licences", "⚡  Electricity", "🏦  Bank Transfer", "🧾  Receipts").forEach {
                Card(Modifier.fillMaxWidth()) {
                    Text(it, Modifier.padding(18.dp), fontWeight = FontWeight.SemiBold, color = Navy)
                }
            }
        }
    }
}

private fun openWhatsApp() {
    // Placeholder hook; production version will open WhatsApp directly.
}
