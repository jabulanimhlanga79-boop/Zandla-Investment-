# Zandla Investment Android App — Version 1.0

This is the first working UI prototype for Zandla Investment.

## Included
- Home dashboard
- Flash Token request screen
- DStv request screen
- Airtime & Data request screen
- More Services
- Transaction History
- Account screen
- WhatsApp contact button
- Zandla blue/gold visual branding

## Current transaction mode
Version 1.0 is intentionally request/manual-payment based. API integrations can be connected later.

## Open in Android Studio
1. Extract the ZIP.
2. Open the `ZandlaInvestment` folder in Android Studio.
3. Let Gradle sync.
4. Run on an Android phone/emulator.

## Next production work
- Add the official Zandla Investment logo asset.
- Add real payment methods.
- Connect Flash API.
- Connect DStv API/provider.
- Connect airtime/data provider.
- Add backend/database and customer authentication.
- Add real receipts and transaction status.
- Add secure admin dashboard.
- Prepare Google Play release.
