# Zandla Investment Android App

Version 1.0 — first working interface.

Services:
- DStv
- Airtime & Data
- Flash Services
- Payments
- Other Services

Contact: 76610622
Retail Code: 930242
