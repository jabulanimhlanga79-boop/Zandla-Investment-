package com.zandla.investment

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 20)
            setBackgroundColor(Color.rgb(7, 26, 51))
        }

        val title = TextView(this).apply {
            text = "ZANDLA INVESTMENT"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setTypeface(null, 1)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 70))

        val sub = TextView(this).apply {
            text = "Your trusted digital services partner"
            textSize = 15f
            setTextColor(Color.rgb(212, 167, 44))
            gravity = Gravity.CENTER
        }
        root.addView(sub, LinearLayout.LayoutParams(-1, 50))

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val services = listOf(
            "📺  DStv Services",
            "⚡  Airtime & Data",
            "🖨️  Flash Services",
            "💳  Payments",
            "📱  Other Services"
        )

        services.forEach { service ->
            val button = Button(this).apply {
                text = service
                textSize = 18f
                setOnClickListener {
                    Toast.makeText(this@MainActivity, "$service selected", Toast.LENGTH_SHORT).show()
                }
            }
            box.addView(button, LinearLayout.LayoutParams(-1, 62).apply {
                setMargins(0, 8, 0, 8)
            })
        }

        val contact = TextView(this).apply {
            text = "\nContact Us\nCall / WhatsApp: 76610622\nRetail Code: 930242"
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        box.addView(contact)

        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
}
